var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["0410f320-5f30-4815-8130-5fffa7468581","863cd403-82c1-4e16-8c18-5d857583bac5","815a413a-1e3e-4d87-b93e-019649bde283","1ef9b6a3-91c3-4445-bde7-3aed1e441e4d"],"propsByKey":{"0410f320-5f30-4815-8130-5fffa7468581":{"name":"Davi","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"7iB_qIU054NyIGEISnjUI77EPFKrqo09","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/0410f320-5f30-4815-8130-5fffa7468581.png"},"863cd403-82c1-4e16-8c18-5d857583bac5":{"name":"arvore","sourceUrl":"assets/v3/animations/yRrWhL-exur7A2e1tfjR09EJ4rgpdgfsldUSQyxD1WA/863cd403-82c1-4e16-8c18-5d857583bac5.png","frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":60,"version":"3VAspmANS8MFPyOp3pQ3EcrBrdJMLMtD","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/v3/animations/yRrWhL-exur7A2e1tfjR09EJ4rgpdgfsldUSQyxD1WA/863cd403-82c1-4e16-8c18-5d857583bac5.png"},"815a413a-1e3e-4d87-b93e-019649bde283":{"name":"carro","sourceUrl":"assets/v3/animations/yRrWhL-exur7A2e1tfjR09EJ4rgpdgfsldUSQyxD1WA/815a413a-1e3e-4d87-b93e-019649bde283.png","frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":4,"version":"66in2GlejJpOHRN.Nw4ahqH73JckoV_y","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/v3/animations/yRrWhL-exur7A2e1tfjR09EJ4rgpdgfsldUSQyxD1WA/815a413a-1e3e-4d87-b93e-019649bde283.png"},"1ef9b6a3-91c3-4445-bde7-3aed1e441e4d":{"name":"chave","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"1KbtWgMFYTpur4cyK9UBC3T_QdrVr1hQ","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/1ef9b6a3-91c3-4445-bde7-3aed1e441e4d.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

// Estado do jogo

var gameState = "serve";

// Personagens

var Davi = createSprite(50,30,20,20);
Davi.setAnimation("Davi");
Davi.scale = 0.7;

// Carro

var carro = createSprite(275,283,5,5);
carro.setAnimation("carro");
carro.scale = 0.9;

// Árvores

var arvore1 = createSprite(50,120,1,1);
arvore1.setAnimation("arvore");
arvore1.scale = 0.9;

var arvore2 = createSprite(150,170,1,1);
arvore2.setAnimation("arvore");
arvore2.scale = 0.9;

var arvore3 = createSprite(50,250,1,1);
arvore3.setAnimation("arvore");
arvore3.scale = 0.9;

var arvore4 = createSprite(200,250,1,1);
arvore4.setAnimation("arvore");
arvore4.scale = 0.9;

var arvore5 = createSprite(370,90,1,1);
arvore5.setAnimation("arvore");
arvore5.scale = 0.9;

var arvore6 = createSprite(305,60,1,1);
arvore6.setAnimation("arvore");
arvore6.scale = 0.9;

// Passagem secreta

var parede = createSprite(200,300,400,5);

// Chave

var chave = createSprite(15,350,1,1);
chave.setAnimation("chave");
chave.scale = 0.7;

// ----

createEdgeSprites();

function draw(){
  background("lightgreen");
  
  // Paredes - Limites
  
  Davi.bounceOff(arvore1);
  Davi.bounceOff(arvore2);
  Davi.bounceOff(arvore3);
  Davi.bounceOff(arvore4);
  Davi.bounceOff(arvore5);
  Davi.bounceOff(arvore6);
  Davi.bounceOff(carro);
  Davi.bounceOff(chave);
  
  Davi.bounceOff(edges);
  
  // Condições
  
  
  
  // Estados do jogo
  
  if(gameState == "play"){
    
      if(keyDown("up")){
    
    Davi.y = Davi.y -3;
    
  }
  
  if(keyDown("left")){
    
    Davi.x = Davi.x -3;
    
  }
  
  if(keyDown("right")){
    
    Davi.x = Davi.x +3;
    
  }
  
  if(keyDown("down")){
    
    Davi.y = Davi.y +3;
    
   }
  }
  
  // ----
  
  if(gameState == "serve"){
    
    text("Pressione a tecla ESPAÇO para começar o jogo!", 100, 320);
    
    text("Toque em algum elemento da floresta para desbloquear a barreira.", 43, 350);
    
    text("Dica: O que é largo mas é bem fino, ultrapassa mas não era pra ", 50, 360);
    text("acontecer isso? Pense bem...", 100, 370);
    
    
    text("Estória: Você está preso na floresta e o seu objetivo é coseguir", 60, 330);
    text("pegar a chave em baixo da barreira para voltar para casa!", 87, 340);
    
    if(keyDown("space")){
      
      gameState = "play";
      
   }
  }

if(gameState == "end"){
  
  text("Você conseguiu escapar! Era pegadinha!!", 150, 345);
  text("Pressione a tecla CONFIRMAR para reiniciar o jogo!", 110, 370);
  
}

if(Davi.isTouching(chave)){
  
  gameState = "end";
  
  
  
        Davi.y = Davi.y -0;
    
  }
  
  if(keyDown("left")){
    
    Davi.x = Davi.x -0;
    
  }
  
  if(keyDown("right")){
    
    Davi.x = Davi.x +0;
    
  }
  
  if(keyDown("down")){
    
    Davi.y = Davi.y +0;
    
 }

  if(keyDown("enter")){
    
    Davi.x = 50;
    
    Davi.y = 30;
    
    gameState = "play";
    
  }

  // ---
  
  drawSprites();
}
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
